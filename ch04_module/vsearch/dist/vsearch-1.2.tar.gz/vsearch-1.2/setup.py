from setuptools import setup

setup(
    name='vsearch',
    version='1.2',
    description='searching tools',
    author='redshore',
    author_email='isutare412@gmail.com',
    url='headfirstlabs.com',
    py_modules=['vsearch']
)
