testing module distribution
