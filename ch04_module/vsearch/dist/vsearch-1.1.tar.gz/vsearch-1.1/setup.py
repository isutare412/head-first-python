from setuptools import setup

setup(
    name='vsearch',
    version='1.1',
    description='searching tools',
    author='redshore',
    author_email='blahblah@gmail.com',
    url='headfirstlabs.com',
    py_modules=['vsearch']
)
